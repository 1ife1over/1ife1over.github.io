function [yearf1,monthf,dayf]=doy2ymd2f(timef1)
yearf1=fix(timef1);
globk_temp2=timef1-yearf1;
[daytotalf]=lsleap(yearf1);
doyf1=fix(globk_temp2*daytotalf)+1;
    montf(1)=31;
if (daytotalf == 365)
    montf(2)=59;
    montf(3)=90;
    montf(4)=120;
    montf(5)=151;
    montf(6)=181;
    montf(7)=212;
    montf(8)=243;
    montf(9)=273;
    montf(10)=304;
    montf(11)=334;
    montf(12)=365;
elseif (daytotalf == 366)
    montf(2)=60;
    montf(3)=91;
    montf(4)=121;
    montf(5)=152;
    montf(6)=182;
    montf(7)=213;
    montf(8)=244;
    montf(9)=274;
    montf(10)=305;
    montf(11)=335;
    montf(12)=366;
end
for if1=1:12
      if (doyf1 <= montf(if1))
          monthf=if1;
          break
      end
end
   if (monthf ==1)
         dayf=doyf1;
   else
         dayf=doyf1-montf(monthf-1);
   end
end