% 
clear all;
close all;
clc;

%% read grd data
DataFolder='/media/student/MybookZhao2/zhaoxiangjun_taiyuan/model_zxj';
%%% data folder
Data=dir(fullfile(DataFolder,'20*_mask_ll_referenced.grd'));
FileNames={Data.name};
numfiles=length(FileNames);
OutFolder='/media/student/MybookZhao2/zhaoxiangjun_taiyuan/model_out';

mat_line=2790;
mat_col=2570;
disp_ts=NaN(mat_line*mat_col,numfiles);
for i=1:numfiles
   str1=cell2mat(FileNames(i));
   str2=fullfile(DataFolder,str1);
   [lon,lat,disp]=grdread2(str2);
   disp_ts(:,i)=disp(:);
end

% Compute the three-point centered moving average
disp_ts=movmean(disp_ts,3,2);

%save the smoothed displacement
for i=1:numfiles
    str1=cell2mat(FileNames(i));
    str2=fullfile(OutFolder,str1);
    display(str2);
    temp=reshape(disp_ts(:,i),[mat_line,mat_col]);
    temp=single(temp);
    grdwrite2(lon,lat,temp,str2);
end




