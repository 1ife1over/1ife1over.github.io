function decimal_month = day_of_year_to_decimal_month(year, day_of_year)
    % 创建该年第一天的日期
    first_day = datetime(year, 1, 1);
    
    % 计算目标日期（年第一天 + 天数-1）
    target_date = first_day + days(day_of_year - 1);
    
    % 获取该日期的月份和日数
    month_num = month(target_date);
    day_num = day(target_date);
    
    % 获取该月的总天数
    days_in_month = day(datetime(year, month_num, 1) + calmonths(1) - days(1));
    
    % 计算小数月份
    decimal_month = month_num + (day_num - 1) / days_in_month;
end