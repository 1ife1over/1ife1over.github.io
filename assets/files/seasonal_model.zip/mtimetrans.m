clear all;
close all;
clc;
year1=2008;
month1=1;
day1=1;

[doy1]=ymd2doy(year1,month1,day1);
daytotal1=lsleap(year1);
time1=year1+(doy1/daytotal1);
