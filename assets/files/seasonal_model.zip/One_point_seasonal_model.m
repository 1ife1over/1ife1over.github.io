clear
%% read data
file=load('A1217_ts_disp.txt');
sardate=file(:,1);
displacement=file(:,2);

% convert the dates to decimal year
sardate=num2str(sardate);
sartime=NaN(size(sardate,1),1);
for k=1:size(sardate,1)
    sar_date=sardate(k,:);
    yyyy=str2double(sar_date(1:4));
    mm=str2double(sar_date(5:6));
    dd=str2double(sar_date(7:8));
    [doy]=ymd2doy(yyyy,mm,dd);
    daytotal=lsleap(yyyy);
    sar_time=yyyy+(doy-0.5)/daytotal;
    sartime(k)=sar_time;
end

%%% fit the time-dependent displacement
i=1;
[a,b,c,d,e,f,~,accurracy,model,residuals]=line_ansef(sartime,displacement);
linear_vel(i)=b;
amp_annual(i)=sqrt(c^2+d^2);
amp_semiannual(i)=sqrt(e^2+f^2);
phase_annual(i)=qtan(d,c)*180/pi/30; %convert phase in radian to months
phase_semiannual(i)=qtan(f,e)*180/pi/30;
%%% calculate the RMS between y and the fitted model
rms(i)=sqrt(sum(residuals.^2)./length(residuals));     
line=a+b*sartime;

%%%%%%%%%%%%%%%%%%%%output
figure;
plot(sartime,displacement)
hold on
plot(sartime,model)
hold on
plot(sartime,line)








