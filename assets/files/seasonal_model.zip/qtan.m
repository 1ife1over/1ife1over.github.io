function jd=qtan(x,y)
pi2=4*atan(1);
if ( x == 0 ) 
       if (y < 0) 
           jd=3*pi2/2;
       else
           jd=pi2/2;
       end 
   else
        jd=atan(abs(y/x));
        if (y == 0) 
           if (x > 0) 
              jd=0;
           else
              jd=pi2;
           end 
        else
            if (y < 0) 
                if (x > 0) 
                    jd=2*pi2-jd;
                else
                    jd=pi2+jd;
                end
           else
                if (x < 0) 
                    jd=pi2-jd;
                 end 
            end
        end
   end
end