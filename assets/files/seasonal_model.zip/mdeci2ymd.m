close all;
clear all;
clc;
strtmp1=filesep;
fileFolder='E:\files\gps\results\yice_gps\2007\data';
dirOutput=dir(fullfile(fileFolder,'*.neulittle07.dat'));
fileNames={dirOutput.name};
num1=length(fileNames);
neulittlefolder='E:\files\gps\results\yice_gps\2007\dataymd';


for i=1:num1
    i
  str1=cell2mat(fileNames(i));
  str2=fullfile(fileFolder,str1);
  %str2=strcat(fileFolder,str1)
  fid1=fopen(str2,'rt');
  %site1=zeros(1000,4);
  clear n1 e1 u1 time1 sn1 se1 su1  site1 ;
  [time1,n1,e1,u1,sn1,se1,su1,site1]=textread(str2,'%f%f%f%f%f%f%f%s',6000);
  fclose(fid1);
  num1=length(n1);
     sitename=cell2mat(site1(1));


 output2=strcat(neulittlefolder,strtmp1,sitename(1:4),'.neulittle07.dat');
 fp22=fopen(output2,'wt');
  for i2=1:num1  
     [year1(i2),month1(i2),day1(i2)]=doy2ymd2f(time1(i2));
    fprintf(fp22,'%d  %d  %d  %5.2f  %5.2f  %5.2f  %5.2f  %5.2f  %5.2f  %s\n',year1(i2),month1(i2),day1(i2),n1(i2),e1(i2),u1(i2),sn1(i2),se1(i2),su1(i2),sitename(1:4));
  end
   fclose(fp22);
  clear n1 e1 u1 time1 sn1 se1 su1  site1 year1 month1 day1 ;
end
