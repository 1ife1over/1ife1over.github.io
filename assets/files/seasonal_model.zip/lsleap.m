function [leapyearf]=lsleap(yearf)

leapyearf=365;

mod1f=mod(yearf,400);
mod2f=mod(yearf,4);
mod3f=mod(yearf,100);
if ((mod1f == 0) || ((mod2f == 0) && (mod3f ~= 0)))
    leapyearf=366;
end

end