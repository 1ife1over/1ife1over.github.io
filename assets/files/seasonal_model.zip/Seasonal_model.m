
clear
%% read grd data
DataFolder='/media/student/MyBookWang1/zhaoxiangjun_taiyuan/model_boke';
%%% data folder
Data=dir(fullfile(DataFolder,'20*_mask_ll_referenced.grd'));
FileNames={Data.name};
numfiles=length(FileNames);
OutFolder='/media/student/MyBookWang1/zhaoxiangjun_taiyuan/model_boke';

mat_line=2570;
mat_col=2790;
disp_ts=NaN(mat_line*mat_col,numfiles);
for i=1:numfiles
   str1=cell2mat(FileNames(i));
   str2=fullfile(DataFolder,str1);
   [lon,lat,disp]=grdread2(str2);
   disp_ts(:,i)=disp(:);
end


% convert the dates to decimal year
sardate=load('dates.list');
sardate=num2str(sardate);
sartime=NaN(size(sardate,1),1);
for k=1:size(sardate,1)
    sar_date=sardate(k,:);
    yyyy=str2double(sar_date(1:4));
    mm=str2double(sar_date(5:6));
    dd=str2double(sar_date(7:8));
    [doy]=ymd2doy(yyyy,mm,dd);
    daytotal=lsleap(yyyy);
    sar_time=yyyy+(doy-0.5)/daytotal;
    sartime(k)=sar_time;
end

 %%% fit the time-dependent displacement
 linear_vel=NaN(mat_line*mat_col,1);
 amp_annual=NaN(mat_line*mat_col,1);
 amp_semiannual=NaN(mat_line*mat_col,1);
 phase_annual=NaN(mat_line*mat_col,1);
 phase_semiannual=NaN(mat_line*mat_col,1);
 rms=NaN(mat_line*mat_col,1);
for i=1:mat_line*mat_col
   if (isnan(mean(disp_ts(i,:)))==0)
   displacement=disp_ts(i,:)';
   [a,b,c,d,e,f,~,accurracy,model,residuals]=line_ansef(sartime,displacement);
   %b_accurracy=accurracy(1);
   linear_vel(i)=b;
   amp_annual(i)=sqrt(c^2+d^2);
   amp_semiannual(i)=sqrt(e^2+f^2);
   phase_annual(i)=qtan(d,c)*180/pi/30; %convert phase in radian to months
   phase_semiannual(i)=qtan(f,e)*180/pi/30;
   %%% calculate the RMS between y and the fitted model
   rms(i)=sqrt(sum(residuals.^2)./length(residuals));  
   end
end

%%%%%%%%%%%%%%%%%%%%output
linear_vel=single(reshape(linear_vel,[mat_line,mat_col]));
grdwrite2(lon,lat,linear_vel,'linear_velocity.grd');

amp_annual=single(reshape(amp_annual,[mat_line,mat_col]));
grdwrite2(lon,lat,amp_annual,'amp_annual.grd');

amp_semiannual=single(reshape(amp_semiannual,[mat_line,mat_col]));
grdwrite2(lon,lat,amp_semiannual,'amp_semiannual.grd');

phase_annual=single(reshape(phase_annual,[mat_line,mat_col]));
grdwrite2(lon,lat,phase_annual,'phase_annual.grd');

phase_semiannual=single(reshape(phase_semiannual,[mat_line,mat_col]));
grdwrite2(lon,lat,phase_semiannual,'phase_semiannual.grd');


rms=single(reshape(rms,[mat_line,mat_col]));
grdwrite2(lon,lat,rms,'rms.grd');



