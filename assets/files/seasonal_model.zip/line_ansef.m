function [af1,vef1,amf1,bmf1,amf2,bmf2,sigma1,sigf1,yfit1,vv1]=line_ansef(timef1,yf1)
% model:y=a+b*t+c*sin(2*pi*t)+d*cos(2*pi*t)+e*sin(4*pi*t)+f*cos(4*pi*t)+epslon
%%%% solve linear velocity-vef1
%%%% amplitude of sin -amf1
%%%% amplitude of cos -bmf1
clear at1 vf1 yfit1 sigf1;
numt1=length(timef1);
numy1=length(yf1);
if (numt1 == numy1)
    for if1=1:numt1
        at1(if1,1)=1;
        at1(if1,2)=timef1(if1);%%at1 is matrix of A
        at1(if1,3)=sin(2*pi*timef1(if1));
        at1(if1,4)=cos(2*pi*timef1(if1));
        at1(if1,5)=sin(4*pi*timef1(if1));
        at1(if1,6)=cos(4*pi*timef1(if1));
    end
    vf1=at1\yf1;
    af1=vf1(1);
    vef1=vf1(2);
    amf1=vf1(3);
    bmf1=vf1(4);
    amf2=vf1(5);
    bmf2=vf1(6);
    yfit1=at1*vf1;
     vv1=yf1-yfit1;
    sigma1=sqrt((vv1'*vv1)/(numy1-6));
    var=inv(at1'*at1);
    sigf1(1)=sqrt(var(2,2))*sigma1;%%%% accuracy of velocity
    sigf1(2)=sqrt(var(3,3))*sigma1;%%%% accuracy of amf1
    sigf1(3)=sqrt(var(4,4))*sigma1;%%%% accuracy of bmf1
    sigf1(4)=sqrt(var(5,5))*sigma1;%%%% accuracy of amf2
    sigf1(5)=sqrt(var(6,6))*sigma1;%%%% accuracy of bmf2
else
  msgbox('the size of time is not equal to y','matrix not match','warn');
  return
end
end